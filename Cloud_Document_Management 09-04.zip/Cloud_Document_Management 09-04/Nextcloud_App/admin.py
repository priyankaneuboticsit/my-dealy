from django.contrib import admin
from Nextcloud_App.models import Contact

# Register your models here.
admin.site.register(Contact)
