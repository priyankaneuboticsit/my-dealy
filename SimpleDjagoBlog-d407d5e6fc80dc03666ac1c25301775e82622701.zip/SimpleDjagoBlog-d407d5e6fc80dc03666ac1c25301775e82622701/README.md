# SimpleDjagoBlog
A minimilistic Django Blog
